# Command : /share/apps/opt/intel/oneapi/intelpython/python3.9/bin/python3 ROET_g16_ver1.py INPUT/hoge0.log INPUT/hoge1.log

import sys
import numpy as np
import scipy.stats as sts
import csv
import pandas as pd
import copy
import time

# Useful function
def __get_block_data(f_, maxlines, start):
    outdata = []
    for _ in range(maxlines):  # for_loop to read data from f_
        l = f_.readline()  # read a line
        l_data = l[start:].strip().split()  #  dvide up data_line after n words
        l_data = [s.replace('D', 'e') for s in l_data]  # change D to e
        if len(l_data) < 5:  # if l_data don't have five elements, you  have to add 0_elements to l_data 
            nzero = 5 - len(l_data)  # how meny 0_elements do you need?
            plus_zero = np.zeros(nzero)  # generate 0_elements
            l_data.extend(plus_zero)  # connect l_data and 0_elements
        l_data = list(map(float, l_data))  # change l_data's type float by map function
        outdata.append(l_data)  # temporarily, save a l_data
    return outdata

def __slice_data_blok(file_name, start_slice, axis):
    outdata = []
    slice_start = orb_max_int  # decide slice start point
    outdata = np.delete(file_name, np.s_[start_slice:], axis)  # remove 0_line、make input_matrix to square matrix
    return outdata

def __coeff_ortho(mat_S, mat_C):
    # coefficiant symmetric orthogonalization : Szabo p.156-158
    ortho_C = []
    mat_S = np.matrix(mat_S)  # setting of overlap matrix S
    mat_C = np.matrix(mat_C).transpose()  # setting of coefficiant matrix C
    eig_s, mat_U = np.linalg.eig(mat_S)  # get eigenvalue s and unitary matrix U of S
    eig_s_root = eig_s ** -0.5  # rise eigenvalue s to the -1/2 th power
    mat_s = np.diag(eig_s_root)  # convert them to diagonal matrix
    mat_X = mat_U @ mat_s @ np.linalg.inv(mat_U)  # get transformation matrix X
    ortho_C = np.linalg.inv(mat_X) @ mat_C  # get new coefficiant C'
    ortho_C = np.transpose(ortho_C)
    return ortho_C

def __get_fchk_block_data(f_, orb_max_int, data_type):
    outdata = []
    tmp_outdata = []
    if data_type == "Energy":  # to read orbital energies
        if orb_max_int % 5 == 0:  # how meny times do you read line
            data_total = orb_max_int // 5
        else:
            data_total = orb_max_int // 5 + 1
    elif data_type =="Coeff" or data_type == "Ortho":  # to read coefficiants or orthonormal basis
        if orb_max_int % 5 == 0:  # how meny times do you read
            data_total = ( orb_max_int ** 2 ) // 5
        else:
            data_total =  ( orb_max_int ** 2 ) // 5 + 1
    for _ in range(data_total):
        l = f_.readline()  # read a line
        l_data = l.strip().split()  #  devide line
        l_data = [s.replace('E', 'e') for s in l_data]  # change E to e
        l_data = list(map(float, l_data))  # make them type float
        tmp_outdata.extend(l_data)  # temporarily, save data
    if data_type == "Energy":  # when energies, 1D list
        outdata.extend(tmp_outdata)
    else:  # when others, make it 2D matrix
        start = 0
        end = orb_max_int
        for _ in range(orb_max_int):
            if start == 0:
                outdata.append(tmp_outdata[start:end])
            else:    
                outdata = np.vstack([outdata, tmp_outdata[start:end]])
            start = end
            end = end + orb_max_int
    return outdata        
            
def _masked(arr, masking_indx):
    return arr[masking_indx]  # masking a list or matrix

def __trace_orbitals(arr_coeff, arr_overlap, arr_ene, irc_points, orb_max_int):
    outdata_tracked_coeff, outdata_tracked_ene, outdata_tracked_coeff_indx = [], [], []
    outdata_check_dotmat = []
    ref_coeff_indx = list(range(orb_max_int))  # generate first refarence coefficiant index
    if arr_overlap.size > 0:
        prv_orth_coeff = __coeff_ortho(arr_overlap[0], arr_coeff[0])
        for now_coeff, now_overlap, now_ene, now_point in zip(arr_coeff, arr_overlap, arr_ene, irc_points):
            """
            dotmat =  now_orth_coeff @ prv_orth_coeff.T
                   = [[now_orb     1 -----------],     [[prv_orb1, prv_orb2, prv_orb3, prv_orb4, prv_orb5],
                      [now_orb     2 -----------],      [    |         |         |         |         |   ],   
                      [now_orb     3 -----------],  @   [    |         |         |         |         |   ],
                      [now_orb     4 -----------],      [    |         |         |         |         |   ],
                      [now_orb     5 -----------]]      [    |         |         |         |         |   ]]
            """
            print()
            print("point " + str(now_point) + " to " + str(now_point + 1) + " tracing")
            # setting
            now_orth_coeff = __coeff_ortho(now_overlap, now_coeff)
            now_orth_coeff = _masked(now_orth_coeff, ref_coeff_indx)
            now_ene = _masked(now_ene, ref_coeff_indx)
            now_coeff = _masked(now_coeff, ref_coeff_indx)
            # calcurate inner product
            dotmat = now_orth_coeff @ prv_orth_coeff.T  # take overlap of coefficiants
            print()
            print("overlap calculation is complete")
            dotmat_abs = np.abs(dotmat)
             
            # rank
            """
            dotmat_rank = [[ 3 12 26 14 28 19 40]
                           [12  6 20 16 28 48 24]
                           [26 20  2 42 28 22  8]
                           [14 16 42  5 28 10 47]    the largest is 1, the smallest is orb_max_int
                           [28 28 28 28  4 28 28]    
                           [18 49 23 10 28  1 44]    method='min' means same number has same rank, 
                           [40 24  8 46 28 44  7]]         rank 10 == rank 10
            """
            dotmat_rank = sts.rankdata(-dotmat_abs, method='min').reshape(dotmat.shape)
            """
            dotmat_rank_fla = [3 12 26 14 28 19 40 12 ........ 46 28 44 7]
            """
            dotmat_rank_fla = list(dotmat_rank.flatten())  # make dotmat_rank flat list
            print()
            print("overlap ranking is now complete")
            # trace
            """
            for trace, if we use =, we rewrite data such as index, coeff and energy.
            so we use copy method hear.
            because, copy method don't rewrite original data!!
            """
            _tracking_coeff_indx = copy.deepcopy(ref_coeff_indx)  # copy index data
            _tracking_orth_coeff = copy.deepcopy(now_orth_coeff)  # copy ortholized coefficient
            _tracking_coeff = copy.deepcopy(now_coeff)  # copy coefficient
            _tracking_ene = copy.deepcopy(now_ene)  # copy energy
            selected_prv, selected_now = [], []  # set empty list for now_step and prv_step traced orbital number
            filled = [False] * len(dotmat_abs)  # set list for completion conditions
            """
            sorted(dotmat_rank_fla) = [1 2 3 4 5 6 7 8 8 ....  ]
            """
            for irank in sorted(dotmat_rank_fla):  # for loop to trace orbital energy
                """
                completion condition
                start :  filled = [False False ........ False]

                finish:  filled = [True True .......... True]
                """
                if np.all(filled):  # completion conditions
                    break
                rank_indx = dotmat_rank_fla.index(irank)  # set index of irank'th overlap orbital number
                i_now, j_prv = divmod(rank_indx, len(dotmat_abs))  # Index of inner product matrix
                dotmat_rank_fla[rank_indx] = -1  # make already traced orbital rank -1 to neglect these orbitals
                if (irank in dotmat_rank_fla) and ((j_prv in selected_prv) or (i_now in selected_now)):  # detect bug state
                    print("bug")
                    quit()
                if (j_prv not in selected_prv) and (i_now not in selected_now):
                    #print("not bug")
                    _tracking_coeff_indx[j_prv] = ref_coeff_indx[i_now]  # connect index i_now to j_prv
                    _tracking_coeff[j_prv] = now_coeff[i_now]  # connect coeff i_now to j_prv
                    _tracking_orth_coeff[j_prv] = now_orth_coeff[i_now]  # same
                    _tracking_ene[j_prv] = now_ene[i_now]  #same
                    selected_prv.append(int(j_prv))
                    selected_now.append(int(i_now))
                    filled[i_now] = True  # already traced orbital rabeled "True"
            outdata_tracked_coeff_indx.append(_tracking_coeff_indx)  # save traced coefficient index
            outdata_tracked_coeff.append(_tracking_coeff.tolist())  # save traced coefficientj
            outdata_tracked_ene.append(_tracking_ene.tolist())  # save traced orbital energy    
            # updata
            prv_orth_coeff = _tracking_orth_coeff  # updata of ortholized coeff
            ref_coeff_indx = _tracking_coeff_indx  # updata of index
    else:
        print("!!WARNING!! Calculating Inner Product Matrix Without Overlap Matrix")
        prv_coeff = arr_coeff[0]
        for now_coeff, now_ene, now_point in zip(arr_coeff, arr_ene, irc_points):
            print()
            print("point " + str(now_point) + " to " + str(now_point + 1) + " tracing")
            prv_norm, now_norm = [], []
            now_ene = __masked(now_ene, ref_coeff_indx)
            now_coeff = __masked(now_coeff, ref_coeff_indx)
            #print(dotmat)
            for i in range(orb_max_int):  # calcurate each vectors norms
                i_prv_norm = prv_coeff[i] @ prv_coeff[i]
                i_now_norm = now_coeff[i] @ now_coeff[i]
                prv_norm.append(i_prv_norm)
                now_norm.append(i_now_norm)
            dotmat = []
            for i in range(orb_max_int):  # calcurate inner product
                for j in range(orb_max_int):
                    tmp_dotmat = now_coeff[i] @ prv_coeff[j]
                    if now_norm[i] != 0 and prv_norm[j] != 0:
                        tmp_dotmat = tmp_dotmat / ((now_norm[i])**(1/2) * (prv_norm[j])**(1/2))
                    dotmat.append(tmp_dotmat)
            print()
            print("overlap calculation is complete")
            dotmat_abs = np.abs(dotmat)
            # inner product check
            #dotmat_start = (i_th_orb - 1) * orb_max_int
            #dotmat_end = i_th_orb * orb_max_int
            #outdata_check_dotmat.append(dotmat_abs[dotmat_start:dotmat_end])  # check inner product with i th orbital    
            # rank
            dotmat_rank = sts.rankdata(-dotmat_abs, method='min')
            dotmat_rank = list(dotmat_rank)
            print()
            print("overlap ranking is now complete")
            # trace
            _tracking_coeff_indx = copy.deepcopy(ref_coeff_indx)  # copy index data
            _tracking_coeff = copy.deepcopy(now_coeff)  # copy coefficient
            _tracking_ene = copy.deepcopy(now_ene)  # copy energy
            selected_prv, selected_now = [], []  # set empty list for now_step and prv_step traced orbital number
            filled = [False] * len(dotmat_abs)  # set list for completion conditions

            for irank in sorted(dotmat_rank):  # for loop to trace orbital energy
                if np.all(filled):  # completion conditions
                    break
                rank_indx = dotmat_rank.index(irank)  # set index of irank'th overlap orbital number
                i_now, j_prv = divmod(rank_indx, orb_max_int)  # Index of inner product matrix
                dotmat_rank[rank_indx] = -1  # make already traced orbital rank -1 to neglect these orbitals
                if (irank in dotmat_rank) and ((j_prv in selected_prv) or (i_now in selected_now)):  # detect bug state
                    print("bug")
                    quit()
                if (j_prv not in selected_prv) and (i_now not in selected_now):
                    #print("not bug")
                    _tracking_coeff_indx[j_prv] = ref_coeff_indx[i_now]  # connect index i_now to j_prv
                    _tracking_coeff[j_prv] = now_coeff[i_now]  # connect coeff i_now to j_prv
                    _tracking_ene[j_prv] = now_ene[i_now]  # same
                    selected_prv.append(int(j_prv))
                    selected_now.append(int(i_now))
                    filled[i_now] = True  # already traced orbital rabeled "True"
            outdata_tracked_coeff_indx.append(_tracking_coeff_indx)  # save traced coefficient index
            outdata_tracked_coeff.append(_tracking_coeff.tolist())  # save traced coefficient
            outdata_tracked_ene.append(_tracking_ene.tolist())  # save traced orbital energy    
            # updata
            prv_coeff = _tracking_coeff  # updata of coeff
            ref_coeff_indx = _tracking_coeff_indx  # updata of index
    return outdata_tracked_coeff, outdata_tracked_ene, outdata_tracked_coeff_indx, outdata_check_dotmat

print('start roet-program')
# Main program
input_files = sys.argv[1:]
alpha_ene, alpha_coeff, beta_ene, beta_coeff, overlap, orthonormal_basis = [], [], [], [], [], []

files_reading_start = time.time()

for ifile in input_files:
    aiorb_ene, aiorb_coeff, biorb_ene, biorb_coeff, ioverlap, iorthonormal_basis = [], [], [], [], [], []
    ifile_splt = ifile.split(".")
    ifile_name = ifile_splt[0]
    ifile_log = ifile_name + ".log"
    ifile_fchk = ifile_name + ".fchk"
    output_file_name = ifile.split(".")[0]

    with open(ifile_log) as f:  # read a log file
        nowline = f.readline()  # read a line
        while nowline:
            nowline = nowline.strip()  # remove line break
            nowline_splt = nowline.split()  # devide line by space


            # --- # of Basis Functions
            if len(nowline_splt) > 2 and nowline_splt[1] == "basis" and nowline_splt[2] == "functions,":
                #
                # 74 basis functions,   120 primitive gaussians,    74 cartesian basis functions
                # 
                orb_max = nowline_splt[0]  # get number of total orbitals
                orb_max_int =int(orb_max)  # make it integer
                if orb_max_int % 5 == 0:  # loop number for reading coefficiants from log file
                    n_blocks = orb_max_int // 5
                else:
                    n_blocks = orb_max_int // 5 + 1

            # --- Overlap Matrix
            elif "*** Overlap ***" in nowline:  # start reading overlap
                #  *** Overlap ***
                #                 1             2             3             4             5
                #      1  0.100000D+01
                #      2  0.191447D+00  0.100000D+01
                #      3  0.000000D+00  0.000000D+00  0.100000D+01
                #      4  0.000000D+00  0.000000D+00  0.000000D+00  0.100000D+01
                
                for i in range(n_blocks):  # loop to read overlap matrix S
                    _ = f.readline()  # read a line
                    overlap_max = orb_max_int - i * 5  # overlap integrals are reduced by 5, which also reduces the number of loops 
                    # Get Overlap
                    tmp_ioverlap = __get_block_data(f, overlap_max, 8)  # read overlap matrix
                    #Save Overlap
                    if i == 0:
                        ioverlap = tmp_ioverlap  # at first, save data directly
                    else:
                        zero_mat_index = i * 5  # determination of the number of rows in the 0_matrix for matching heights
                        plus_zero_mat = np.zeros((zero_mat_index, 5))  # generate 0_matrix
                        tmp_ioverlap = np.vstack([plus_zero_mat, tmp_ioverlap])  # connect overlap and 0_matrix
                        ioverlap = np.hstack([ioverlap, tmp_ioverlap])  # stack and save overlap
                if orb_max_int % 5 != 0:
                    ioverlap = __slice_data_blok(ioverlap, orb_max_int, 1)
                # ioverlap is not overlap matrix yet !!!
                # only the lower triangular part of the overlap matrix       
                ioverlap_T = np.transpose(ioverlap)  # make the upper triangular part of the overlap matrix 
                d = np.diag(ioverlap)  # extract diagnal part of overlap matrix
                ioverlap_diag = np.diag(d)  # make diagonal matrix
                ioverlap = ioverlap + ioverlap_T - ioverlap_diag  # complete overlap matrix
                #for i in range(orb_max_int):
                #    print(len(ioverlap[i]))
                #print("----------------------------------------------------------------")                


            # --- !! You should get Coefficients and Orbital Energies from fchk files !!
            # --- Molecular Orbital Coefficients and Orbital Energy in log file
            #elif "Molecular Orbital Coefficients" in nowline:  # start reading orbital coefficiants
                #   Molecular Orbital Coefficients:
                #                         1         2         3         4         5
                #                         O         O         O         O         O
                #   Eigenvalues --   -10.11598 -10.11540 -10.11410 -10.11326 -10.11046
                # 1 1   C  1S         -0.09053  -0.12674   0.69122   0.68365   0.04325
                # 2        2S         -0.01335  -0.01617   0.08298   0.07706   0.00370
                # 3        2PX         0.00041  -0.00060  -0.00026   0.00017   0.00026
                # 4        2PY         0.00061   0.00021   0.00060   0.00019  -0.00119
                # 5        2PZ         0.00031  -0.00013   0.00011  -0.00016   0.00058

                #for i in range(n_blocks):  # big loop to read molecular orbital coefficiants
                    #_ = f.readline()  # read a line
                    #_ = f.readline()  # read a line more
                    #nowline = f.readline()  # one more
                    #nowline_splt = nowline.strip().split()  # remove line break and devide line at space
                    #nowline_splt_float = list(map(float, nowline_splt[2:]))  # chage their type float
                    # Get orbital energy
                    #iorb_ene.extend(nowline_splt_float)  # save orbital energy
                    # Get orbital coefficients
                    #tmp_iorb_coeff = __get_block_data(f, orb_max_int, 19)
                    # Save coeff
                    #tmp_iorb_coeff_T = np.transpose(tmp_iorb_coeff)
                    #if i == 0:
                        #iorb_coeff = tmp_iorb_coeff_T
                    #else:
                        #iorb_coeff = np.vstack([iorb_coeff, tmp_iorb_coeff_T])  # save transposed coefficiants
                #iorb_coeff = __slice_data_blok(iorb_coeff, orb_max_int, 0)  # remove 0 lines, make it square


            # --- !! You already have Number of basis functions !!
            # --- Number of basis functions
            #if "Number of basis functions" in nowline:
                #
                #Number of basis functions                  I               74
                #
                    
                #orb_max = nowline_splt[5]  # get number of orbitals
                #orb_max_int = int(orb_max)  # make it integer
                #print(orb_max_int)
                #print(type(orb_max_int))

            # Update line
            nowline = f.readline() # updata a line (because while loop does not updata automatically)

    with open(ifile_fchk) as g:
        nowline = g.readline()  # read a line
        while nowline:
            nowline = nowline.strip()  # remove line break
            nowline_splt = nowline.split()  # devide by space

            #---Alpha Orbital Energies
            if "Alpha Orbital Energies" in nowline:
                #
                #Alpha Orbital Energies                     R   N=          74
                # -1.01159776E+01 -1.01154039E+01 -1.01141048E+01 -1.01132581E+01 -1.01104611E+01
                # -1.01092676E+01 -8.26021076E-01 -7.32965919E-01 -7.30967145E-01 -6.17855253E-01
                #
                    
                aiorb_ene = __get_fchk_block_data(g, orb_max_int, "Energy")  # get orbital energy
                #print("orbital energy")
                #print(iorb_ene)
                #print(len(iorb_ene))
                #print("-------------------------------------------------------------------------")

            #---Beta Orbital Energies
            elif "Beta Orbital Energies" in nowline:
                #
                #Beta Orbital Energies                      R   N=         207
                # -1.91407263E+01 -1.91244896E+01 -1.91074119E+01 -1.44574372E+01 -1.44276974E+00
                # -1.33384360E+00 -1.11799965E+00 -8.56854230E-01 -7.57060112E-01 -7.13196159E-01
                #

                biorb_ene = __get_fchk_block_data(g, orb_max_int, "Energy")

            # --- Orthonormal basis
            elif "Orthonormal basis" in nowline:
                #
                #Orthonormal basis                          R   N=        5476
                #  1.73813242E-02  7.39014151E-02  1.44076995E-02  2.22487804E-02  6.05855583E-03
                    
                orthonormal_iorb_coeff = __get_fchk_block_data(g, orb_max_int, "Ortho")  # get orthonormal basis
                #print("orthonormal basis")
                #print(orthonormal_iorb_coeff)
                #print("-------------------------------------------------------------------------")

            # --- Alpha MO coefficients 
            elif "Alpha MO coefficients" in nowline:
                #
                #Alpha MO coefficients                      R   N=        5476
                # -9.05317042E-02 -1.33506739E-02  4.06448557E-04  6.08127645E-04  3.10817984E-04
                #  3.61219318E-02 -2.22573922E-04  1.35009518E-02  5.24727930E-03  9.04068209E-02

                aiorb_coeff = __get_fchk_block_data(g, orb_max_int, "Coeff")
                #print("orbital coefficients")
                #print(iorb_coeff)
                #print(np.array(iorb_coeff).ndim)
                #print(len(iorb_coeff))
                #for i in range(orb_max_int):
                #    print(len(iorb_coeff[i]))
                #print("----------------------------------------------------------------------------")

            # --- Beta MO coefficients 
            elif "Beta MO coefficients" in nowline:
                #
                #Beta MO coefficients                       R   N=       42849
                #  1.77190286E-04  8.29353710E-04 -6.96891549E-04  7.09485656E-03  5.53169723E-03
                # -1.73019148E-05  2.83008848E-04 -2.42500904E-04 -1.03970127E-04 -2.57084303E-03
                #

                biorb_coeff = __get_fchk_block_data(g, orb_max_int, "Coeff")




            # Update line
            nowline = g.readline() # while does not updata automatically



    # Save overlap and orbital energy and coeff. for each input file
    alpha_ene.append(aiorb_ene)
    alpha_coeff.append(aiorb_coeff)
    beta_ene.append(biorb_ene)
    beta_coeff.append(biorb_coeff)
    overlap.append(ioverlap)

files_reading_end = time.time()
file_reading_time = files_reading_end - files_reading_start

print("finish reading files")
print("file reading time = " + str(file_reading_time))
#print("------------------------------------------------------------------")
#print('start tracing orbitals')
#orbital_tracing_start = time.time()

# Notice
"""
orb_coeff[i] = [[orbital 1 -------------------------------------------------],
                [orbital 2 -------------------------------------------------],
                                            .
                                            .
                                            .
                [HOMO      -------------------------------------------------],
                [LUMO      -------------------------------------------------],
                                            .
                                            .
                                            .
                [orbital Last ----------------------------------------------]]

i steps orbital x is in (x-1)-th rows, not (x-1)-th column. (x = 1, 2, 3, ....., Last) 

"""

"""with open("test_overlap.csv", "w") as to:
    writer = csv.writer(to)
    writer.writerows(overlap)

with open("test_coeff.csv", "w") as tc:
    writer = csv.writer(tc)
    writer.writerows(orb_coeff)

quit()"""

# Settings
overlap = np.array(overlap)
alpha_ene = np.array(alpha_ene)
alpha_coeff = np.array(alpha_coeff)
beta_ene = np.array(beta_ene)
beta_coeff = np.array(beta_coeff)
prv_coeff = alpha_coeff[0]
irc_point = range(0, len(alpha_ene))
#print(irc_point)
#quit()

# Tracing alpha orbitals
print("=============================")
print("start tracing alpha orbitals")
print("=============================")
a_tracked_all_data = __trace_orbitals(alpha_coeff, overlap, alpha_ene, irc_point, orb_max_int)
a_tracked_coeff = a_tracked_all_data[0]
a_tracked_ene = a_tracked_all_data[1]
a_tracked_indx = a_tracked_all_data[2]
#a_dotmat = a_tracked_all_data[3]
print("=============================")
print("finish tracing alpha orbitals")
print("=============================")

# Tracing beta orbitals
print("=============================")
print("start tracing beta orbitals")
print("=============================")
b_tracked_all_data = __trace_orbitals(beta_coeff, overlap, beta_ene, irc_point, orb_max_int)
b_tracked_coeff = b_tracked_all_data[0]
b_tracked_ene = b_tracked_all_data[1]
b_tracked_indx = b_tracked_all_data[2]
#b_dotmat = b_tracked_all_data[3]
print("=============================")
print("finish tracing beta orbitals")
print("=============================")

print("finish orbital trace completely")

print('start saving results')




# prv_coeff = orb_coeff[0][:5, :5]

#for now_coeff in orb_coeff[1:]:

    # now_coeff = now_coeff[:5, :5]

    # print(prv_coeff)
    # print(now_coeff)
    
#    dotmat = abs(prv_coeff @ prv_coeff.T)
    # dotmat = abs(prv_coeff @ now_coeff.T)

#    print(dotmat)
    
#    quit()

# Add track number in tracked_ene
a_index_tracked_ene, b_index_tracked_ene = [], []
for i, row in enumerate(a_tracked_ene):
    a_index_tracked_ene.append([i + 1] + row)
    
for i, row in enumerate(b_tracked_ene):
    b_index_tracked_ene.append([i + 1] + row)


#np.savetxt('test.csv', dotmat_abs, delimiter=',')

#with open("test.csv", "w") as t:
#    writer = csv.writer(t)
#    writer.writerows(dotmat)    

"""with open("test_ene.csv", "w") as te:
    writer = csv.writer(te)
    writer.writerows(orb_ene)"""
"""
with open("test_overlap.csv", "w") as to:
    writer = csv.writer(to)
    writer.writerows(overlap)

with open("test_coeff.csv", "w") as tc:
    writer = csv.writer(tc)
    writer.writerows(orb_coeff)
"""
# Save tracked deta
with open(str(output_file_name) + "_alpha_ene.csv", "w") as rae:
    writer = csv.writer(rae)
    writer.writerows(a_index_tracked_ene)

with open(str(output_file_name) + "_beta_ene.csv", "w") as rbe:
    writer = csv.writer(rbe)
    writer.writerows(b_index_tracked_ene)

with open(str(output_file_name) + "_alpha_indx.csv", "w") as rai:
    writer = csv.writer(rai)
    writer.writerows(a_tracked_indx)

with open(str(output_file_name) + "_beta_indx.csv", "w") as rbi:
    writer = csv.writer(rbi)
    writer.writerows(b_tracked_indx)

print('finish saving results')

program_end_time = time.time()
total_time= program_end_time - files_reading_start
print('Normal termination of roet-program')
print("total time = " + str(total_time))
